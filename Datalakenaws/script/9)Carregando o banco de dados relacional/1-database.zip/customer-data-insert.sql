INSERT  INTO customer values(0,'pele','silva','1985-10-19');
INSERT  INTO customer values(1,'zico','morais','1989-08-14');
INSERT  INTO customer values(2,'raul','teixeira','1982-08-11');
INSERT  INTO customer values(3,'ronaldo','messias','1990-05-05');
INSERT  INTO customer values(4,'maradona','alcob','1999-06-28');
INSERT  INTO customer values(5,'zinedine','zidane','1991-06-22');
INSERT  INTO customer values(6,'leonel','messi','1994-06-21');